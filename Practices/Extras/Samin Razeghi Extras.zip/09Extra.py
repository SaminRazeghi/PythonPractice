lable = [*input('Please give me the coordinates: ')]
if lable.count("R") > 2:
    print("Nakhor Lite")
elif (lable.count("R") == 2) and (lable.count("Y") > 1):
    print("Nakhor Lite")
elif lable.count("Y") == 5:
    print("Nakhor Lite")
else:
    print("Rahat bash")
