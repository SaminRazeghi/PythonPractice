K = int(input('K ra bade:'))
if K % 2 == 1:
    print("Paein barare")
else:
    print("Bala barare")
